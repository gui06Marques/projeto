package model;

public class Anuncio {
    private int id;
    private String titulo;
    private String descricao;
    private double preco;

    public Anuncio(String titulo, String descricao, double preco) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.preco = preco;
    }

    // Getters e Setters

    @Override
    public String toString() {
        return "ID: " + id + ", Título: " + titulo + ", Descrição: " + descricao + ", Preço: " + preco;
    }
}
