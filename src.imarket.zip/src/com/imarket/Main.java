package com.imarket;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    private static final String URL = "jdbc:mysql://localhost:3306/?user=root";
    private static final String USERNAME = "root";
   

    public static void main(String[] args) {
        try {
            // Conectar ao banco de dados
            Connection connection = DriverManager.getConnection(URL, USERNAME);

            // Exemplo de uso: realizar cadastro de usuário
            cadastrarUsuario(connection);

            // Exemplo de uso: realizar cadastro de anúncio
            cadastrarAnuncio(connection);

            // Exemplo de uso: exibir lista de usuários
            exibirUsuarios(connection);

            // Fechar conexão
            connection.close();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }
    }

    private static void cadastrarUsuario(Connection connection) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Cadastro de Usuário");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();

        // Persistir usuário no banco de dados
        // ...

        System.out.println("Usuário cadastrado com sucesso!");
    }

    private static void cadastrarAnuncio(Connection connection) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Cadastro de Anúncio");
        System.out.print("Título: ");
        String titulo = scanner.nextLine();
        System.out.print("Descrição: ");
        String descricao = scanner.nextLine();

        // Persistir anúncio no banco de dados
        // ...

        System.out.println("Anúncio cadastrado com sucesso!");
    }

    private static void exibirUsuarios(Connection connection) throws SQLException {
        // Obter lista de usuários do banco de dados
        // ...

        System.out.println("Lista de Usuários:");
        // Exibir lista de usuários
        // ...
    }
}

