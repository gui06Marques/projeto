package dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AnuncioDAO {
    private Connection connection;

    public AnuncioDAO() {
        this.connection = DatabaseUtil.getConnection();
    }

    public void criarAnuncio(Anuncio anuncio) {
        String sql = "INSERT INTO anuncios (titulo, descricao, preco) VALUES (?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, anuncio.getTitulo());
            statement.setString(2, anuncio.getDescricao());
            statement.setDouble(3, anuncio.getPreco());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Anuncio> lerAnuncios() {
        List<Anuncio> anuncios = new ArrayList<>();

        String sql = "SELECT * FROM anuncios";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String titulo = resultSet.getString("titulo");
                String descricao = resultSet.getString("descricao");
                double preco = resultSet.getDouble("preco");

                Anuncio anuncio = new Anuncio(titulo, descricao, preco);
                anuncio.setId(id);

                anuncios.add(anuncio);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return anuncios;
    }

    public void atualizarAnuncio(int id, Anuncio anuncioAtualizado) {
        String sql = "UPDATE anuncios SET titulo = ?, descricao = ?, preco = ? WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, anuncioAtualizado.getTitulo());
            statement.setString(2, anuncioAtualizado.getDescricao());
            statement.setDouble(3, anuncioAtualizado.getPreco());
            statement.setInt(4, id);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirAnuncio(int id) {
        String sql = "DELETE FROM anuncios WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
