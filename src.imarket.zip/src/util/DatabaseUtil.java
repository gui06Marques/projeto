package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/imarket";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return connection;
    }

    public static void conectar() {
        getConnection(); // Chamada para estabelecer a conexão
        System.out.println("Conectado ao banco de dados.");
    }

    public static void desconectar() {
        try {
            getConnection().close();
            System.out.println("Desconectado do banco de dados.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}